package de.TheHolyException.suro.utils;

import org.bukkit.entity.Player;

public interface ScoreboardModule {
	
	ScoreboardData getScoreboardData(Player player);

}
